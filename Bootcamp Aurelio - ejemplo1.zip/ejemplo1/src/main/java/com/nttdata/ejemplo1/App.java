package com.nttdata.ejemplo1;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import com.nttdata.taller2.Product;
import com.nttdata.taller2.Tax;

public class App {

	public static void main(String[] args) {

		/**
		 * List<Integer> numbers = List.of(18, 6, 4, 15, 55, 78, 12, 9, 8);
		 * 
		 * // FORMA 1 int contador = 0;
		 * 
		 * for (Integer numero : numbers) {
		 * 
		 * if (numero > 9) { contador++; } }
		 * 
		 * System.out.println("Hay un total de " + contador + " numeros mayores que
		 * 10.");
		 * 
		 * // FORMA 2 long count = numbers.stream().filter(num -> num > 10).count();
		 * System.out.println(count);
		 */

		/** Generamos la lista */
		List<Product> shopping = List.of(new Product("Clothes", new BigDecimal("15.90"), Tax.NORMAL),
				new Product("Bread", new BigDecimal("1.5"), Tax.SUPERREDUCED),
				new Product("Meat", new BigDecimal("13.99"), Tax.REDUCED),
				new Product("Cheese", new BigDecimal("3.59"), Tax.SUPERREDUCED),
				new Product("Coke", new BigDecimal("1.89"), Tax.REDUCED),
				new Product("Whiskey", new BigDecimal("19.90"), Tax.NORMAL));

		Double totales = shopping.stream()
				.mapToDouble(total -> total.price.doubleValue() + (total.tax.percent * total.price.doubleValue() / 100))
				.sum();

		System.out.println(totales);

		/** Productos que empiezan por la C */
		List<String> productosC = shopping.stream().filter(producto -> producto.name.startsWith("C"))
				.map(nombre -> nombre.name).collect(Collectors.toList());

		System.out.println(productosC);
	}
}
