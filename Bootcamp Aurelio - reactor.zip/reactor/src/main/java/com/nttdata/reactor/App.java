package com.nttdata.reactor;

import reactor.core.publisher.Flux;

public class App {

	public static void main(String[] args) {

		Flux<String> messageSender = Flux.just("Mensaje1", "Mensaje2", "Mensaje3");
		
		messageSender.subscribe(t -> System.out.println("Observer 1. Subscribed"),
								m -> System.out.println("Observer 1. Received: " + m),
								e -> System.out.println("Observer 1. Error"));
		
		
//		messageSender.subscribe(new CoreSubscriber() {
//
//			@Override
//			public void onSubscribe(Subscription s) {
//				System.out.println("Observer1. Subscribed.");
//			}
//
//			@Override
//			public void onNext(Object t) {
//				System.out.println("Observer1. Received " + t);
//			}
//
//			@Override
//			public void onError(Throwable t) {
//				System.out.println("Observer1. Error: " + t.getMessage());
//			}
//
//			@Override
//			public void onComplete() {
//				System.out.println("Observer1. Completed.");
//			}
//		
//		});
		
		
		
//		messageSender.subscribe(new CoreSubscriber() {
//
//			@Override
//			public void onSubscribe(Subscription s) {
//				System.out.println("Observer2. Subscribed.");
//			}
//
//			@Override
//			public void onNext(Object t) {
//				System.out.println("Observer2. Received " + t);
//			}
//
//			@Override
//			public void onError(Throwable t) {
//				System.out.println("Observer2. Error: " + t.getMessage());
//			}
//
//			@Override
//			public void onComplete() {
//				System.out.println("Observer2. Completed.");
//			}
//
//		});
		
	}
}
