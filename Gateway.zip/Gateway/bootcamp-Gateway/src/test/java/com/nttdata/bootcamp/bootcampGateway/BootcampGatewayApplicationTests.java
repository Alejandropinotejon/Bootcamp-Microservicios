package com.nttdata.bootcamp.bootcampGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcampGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
