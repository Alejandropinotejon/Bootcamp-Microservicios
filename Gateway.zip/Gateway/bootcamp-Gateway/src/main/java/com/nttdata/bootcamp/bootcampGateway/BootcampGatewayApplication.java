package com.nttdata.bootcamp.bootcampGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootcampGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootcampGatewayApplication.class, args);
	}

}
