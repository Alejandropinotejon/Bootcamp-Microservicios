package bootcamp.saludo_idioma;

public enum TempEnum {
	CELSIUS, FARENHEIT
}
