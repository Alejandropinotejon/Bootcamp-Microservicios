package bootcamp.saludo_idioma;

public class Temperatura {

	private TempEnum sistema;

	public Temperatura(String sistema) {
		this.sistema = TempEnum.valueOf(sistema.toUpperCase());
	}

	public Temperatura() {
		this.sistema = TempEnum.CELSIUS;
	}
	public double conversion(String grados) {

		Double gradosDouble = Double.parseDouble(grados);

		double resultado;

		if (sistema.equals(TempEnum.FARENHEIT)) {
			resultado = (gradosDouble - 32) / 1.8;
		} else {
			resultado = (gradosDouble * 1.8) + 32;
		}
		return gradosDouble;
	}
}
