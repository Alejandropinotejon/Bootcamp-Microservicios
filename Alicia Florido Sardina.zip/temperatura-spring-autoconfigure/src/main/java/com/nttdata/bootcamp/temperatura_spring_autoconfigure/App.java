package com.nttdata.bootcamp.temperatura_spring_autoconfigure;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
