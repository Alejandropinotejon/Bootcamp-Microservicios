/**
 * 
 */
package com.nttdata.bootcamp.pruebasClientes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import bootcamp.saludo_idioma.Saludo;
import bootcamp.saludo_idioma.Temperatura;

/**
 * @author apinotej
 *
 */
@RestController
public class PruebaController {

	
	private Saludo saludo;
	
	
	private Temperatura temperatura;
	
	@GetMapping(path="/prueba")
	public String pruebaSaludo() {
		return saludo.mensajeSaludo();
	}
	
	@GetMapping(path="/grados")
	public String pruebaTemperatura(String grados) {
		return Double.toString(temperatura.conversion(grados));
	}
}
