package com.example.nttdata.bootcampdia2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootcampDia2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
