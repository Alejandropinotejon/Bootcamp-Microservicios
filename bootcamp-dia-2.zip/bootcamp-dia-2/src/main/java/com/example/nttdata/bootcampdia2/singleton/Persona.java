package com.example.nttdata.bootcampdia2.singleton;

/**
 * @author apinotej
 *
 */
public class Persona {
	
}
