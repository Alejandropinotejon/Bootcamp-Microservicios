/**
 * 
 */
package com.example.nttdata.bootcampdia2.PersonaSingleton;

/**
 * @author apinotej
 *
 */
public class PersonaSingleton {

	/** Instancia del objeto */
	private static PersonaSingleton objeto;
	
	/** Atributos */
	private String name;
	private Integer age;
	
	/** Constructor */
	private PersonaSingleton() {}

	/** Método para obtener la instancia */
	public static PersonaSingleton getInstance() {

		if (objeto == null) {
			objeto = new PersonaSingleton();
		}

		return objeto;
	}

	/** operación singleton */
	public void singletonOperation() {
		System.out.println("¡Hola, soy una persona!");
		System.out.println("Mi nombre es " + name + " y mi edad es " + age);
	}
}
