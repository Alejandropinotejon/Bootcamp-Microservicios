package com.nttdata.bootcamp.webfluxappmicro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebfluxAppMicroApplicationTests {

	@Test
	void contextLoads() {
	}

}
