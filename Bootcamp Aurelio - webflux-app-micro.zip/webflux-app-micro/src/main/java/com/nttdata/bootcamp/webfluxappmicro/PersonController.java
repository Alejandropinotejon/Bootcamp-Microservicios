package com.nttdata.bootcamp.webfluxappmicro;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import reactor.core.publisher.Flux;

@RestController
public class PersonController {

	@GetMapping("/person-list-1")
	public Flux<Person> personList1() {
		Flux<Person> flux = Flux.just(new Person("Alejandro", "Pino", 27));
		return flux;
	}

	@GetMapping("/person-list-2")
	public Flux<Person> personList2() {
		Flux<Person> flux = Flux.just(new Person("Persona2", "Prueba2", 37));
		return flux;
	}

	@GetMapping("/person-list-3")
	public Flux<Person> personList3() {
		Flux<Person> flux = Flux.just(new Person("Persona3", "Prueba3", 42));
		return flux;
	}

	@GetMapping("/person-list-4")
	public Flux<Person> personList4() {
		Flux<Person> flux = Flux.just(new Person("Persona4", "Prueba4", 16));
		return flux;
	}

}
