package com.nttdata.bootcamp.webfluxappmicro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebfluxAppMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebfluxAppMicroApplication.class, args);
	}

}
